
package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author trannhi
 */
public class MainInfoServlet extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String URL = "/MainInfo.jsp", msg = "";
        try {
        String aname = request.getParameter("aname");
        String astr1 = request.getParameter("astreet1");
        String astr2 = request.getParameter("astreet2");
        String acity = request.getParameter("acity");
        String astate = request.getParameter("astate");
        String azip = request.getParameter("azip");
        
        String pid = request.getParameter("pID");
        String pfname = request.getParameter("pfname");
        String pmname = request.getParameter("pmname");
        String plname = request.getParameter("plname");
        String pstr1 = request.getParameter("pstreet1");
        String pstr2 = request.getParameter("pstreet2");
        String pcity = request.getParameter("pcity");
        String pstate = request.getParameter("pstate");
        String pzip = request.getParameter("pzip");
        
        if (pstr2.trim().isEmpty()) {
            pstr2 = "None";
        } 
        if (pmname.trim().isEmpty()) {
            pmname = "None"; 
        }
        if (astr2.trim().isEmpty()) {
            astr2 = "None";
        } 
        Connection connection = null;
        String url = "jdbc:mysql://localhost:3306/vaccination";
        String username = "root";
        String password = "sesame";
           
        Class.forName("com.mysql.jdbc.Driver"); 
        connection = DriverManager.getConnection(url, username, password);
        Statement st = connection.createStatement();
        
        st.executeUpdate("INSERT INTO adsite(AD_NAME,AD_STREET1,AD_STREET2,AD_CITY,AD_STATE,AD_ZIPCODE)values('"+aname+"','"+astr1+"','"+astr2+"','"+acity+"','"+astate+"','"+azip+"')");
        st.executeUpdate("INSERT INTO provider(PRO_ID,PRO_LNAME,PRO_INITIAL,PRO_FNAME,PRO_STREET1,PRO_STREET2,PRO_CITY,PRO_STATE,PRO_ZIPCODE)values('"+pid+"','"+plname+"','"+pmname+"','"+pfname+"','"+pstr1+"','"+pstr2+"','"+pcity+"','"+pstate+"','"+pzip+"')");
        
        } catch (ClassNotFoundException e) {
            msg += "JDBC Driver not found in project<br>";
        } catch (SQLException e) {
            msg += "Connection error: " + e.getMessage() + "<br>";
        } catch (Exception e) {
            msg += "Servlet error: " + e.getMessage();
        }
        msg += "Your information was successfully recorded!";
        request.setAttribute("msg", msg);
        RequestDispatcher disp = getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
